# About esx_vehicletheft:
Edited/Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* There are NO Blips. Thats b/c the location is supposed to be hidden. Not everyone should know the location. Maybe in the future i will add a Blip code for this.
* The Delivery Location & Vehicle you get is Random.

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
  * [esx_policejob]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx_addons%5D/esx_policejob )
* Optional:
  * NONE

# Download & Installation:
1) Place `esx_vehicletheft` in your ESX Directory
2) Add `start esx_vehicletheft` to your server.cfg

# Credits/Original Code:
* [KlibrDM]( https://github.com/KlibrDM )
  * [esx_cartheft]( https://github.com/KlibrDM/esx_carthief )
* The ideal was from esx_cartheft but made my own version as mine is more optimized & using better code. In the Future i plan on adding Aircraft & Boat Thefts.
