# About esx_advancedweaponshop:
Edited/Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* This Weapon Shops works similar to esx_weaponshop.
* Players will be required to own different Licenses to purchase certain Weapons.
* Its best to leave Sniper Rifles & LMGs out of the BlackShop so it gives players a job to sell Weapons.
  * If you add LMGs & Snipers in the Blackshop you will have to edit the client/main.lua.

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
* Optional:
  * [esx_licenseshop]( https://github.com/HumanTree92/VENT_ESX_Scripts/tree/main/esx_licenseshop )

# Download & Installation:
1) Import the `esx_advancedweaponshop.sql` into your database.
2) Place `esx_advancedweaponshop` in your ESX Directory
3) Add `start esx_advancedweaponshop` to your server.cfg

# Credits/Original Code:
* [ESX-Framework]( https://github.com/esx-framework )
  * [esx_weaponshop]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx_addons%5D/esx_weaponshop )
