Locales['en'] = {
  ['job_menu'] = 'press ~INPUT_PICKUP~ to access the ~b~Job Center~s~.',
  ['job_center'] = 'Job Center',
  ['new_job'] = 'you have a new job!',
}
