Config = {}
Config.Locale = 'en'

Config.DrawDistance = 100.0
Config.Marker = {Type = 1, r = 100, g = 100, b = 204, x = 1.5, y = 1.5, z = 1.0}

Config.Locs = {
	vector3(198.13, -935.85, 29.69)
}
