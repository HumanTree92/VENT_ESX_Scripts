# About esx_vehiclespawner:
Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* Players able to spawn Vehicles/Trailers listed in the config.lua

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
* Optional:
  * NONE

# Download & Installation:
1) Place `esx_vehiclespawner` in your ESX Directory
2) Add `start esx_vehiclespawner` to your server.cfg
