Locales['en'] = {
	['blip_spawner'] = 'Trailer Spawner',
	['vehicle_spawner'] = 'Trailer Spawner',
	['press_to_enter'] = 'Press ~INPUT_PICKUP~ to take out a Trailer.',
	['press_to_enter2'] = 'Press ~INPUT_PICKUP~ to put away a Trailer.',
	['spawner'] = 'Spawner',
	['list_spawners'] = 'List of Trailers',
	['return_spawners'] = 'Return a Trailer',
	['dont_abuse'] = 'If you Abuse this you will be Banned!',
	['default_veh'] = 'Default Trailers',
	['spawnpoint_blocked'] = 'Trailer spawn point is ~r~blocked~s~!',
}