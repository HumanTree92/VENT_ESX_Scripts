# esx_advancedhospital:
Edited/Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* This is a Combination of Both my esx_hospital & esx_plasticsurgery.
* Players can pay to get Healed or pay to change the looks of their character.

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
  * [esx_skin]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx%5D/esx_skin )
  * [skinchanger]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx%5D/skinchanger )
* Optional:
  * NONE

# Download & Installation:
1) Edit the `config.lua` before starting the script. By default everything is turned off.
2) Place `esx_advancedhospital` in your ESX Directory
3) Add `start esx_advancedhospital` to your server.cfg

# Credits/Original Code:
* [DDH3]( https://github.com/ddh3 )
  * [esx_hospital]( https://github.com/ddh3/esx_hospital )
