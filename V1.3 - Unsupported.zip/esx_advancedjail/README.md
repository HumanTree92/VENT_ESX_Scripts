# About esx_advancedjail:
Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* Allows police to Jail Players in Multiple Locations
* Players can Escape if you set it in the config.lua
* Players can Change into/out of Prison Clothing

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
  * [esx_policejob]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx_addons%5D/esx_policejob )
* Optional:
  * NONE

# Download & Installation:
1) Import the `esx_advancedjail.sql` into your database.
2) Place `esx_advancedjail` in your ESX Directory
3) Add `start esx_advancedjail` to your server.cfg
