# About esx_advancedholdup:
Edited/Made by Human Tree92 ([Velociti Entertainment Customs & Wiki]( http://www.velocitientertainment.com/customs/ ))

# Helpfull Info:
* This has a lot of changes to suit my needs.
* Can pretty much Rob every default Shop, Bank, Etc.

# Requirements:
* Required:
  * [ESX Legacy V1.3 Final]( https://github.com/esx-framework/esx-legacy/tree/1.3.0-final )
  * [esx_policejob]( https://github.com/esx-framework/esx-legacy/tree/main/%5Besx_addons%5D/esx_policejob )
* Optional:
  * NONE

# Download & Installation:
1) Place `esx_advancedholdup` in your ESX Directory
2) Add `start esx_advancedholdup` to your server.cfg

# Credits/Original Code:
* [LuaDeldu]( https://github.com/LuaDeldu )
  * [esx_advanced_holdup]( https://github.com/LuaDeldu/esx_advanced_holdup )
